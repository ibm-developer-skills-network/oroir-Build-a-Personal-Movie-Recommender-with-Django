from . import views
from .models import Movie


# HINT: Create a view to provide movie recommendations list for the HTML template
# def movie_recommendation_view(request):
#    if request.method == "GET":
#        context = {}
#        return render(request, 'recommender/movie_list.html', context)
