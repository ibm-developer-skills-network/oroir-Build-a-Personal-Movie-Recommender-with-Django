from django.db import models


# Create your models here.
# HINT: Create a Movie model here
# Which will be mapped to a database table with columns
class Movie(models.Model):
    """
    Django Movie Model
    """
    pass
